import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:staff_webapp/domain/use_cases/login_use_case.dart';
import 'package:staff_webapp/presentation/bloc/login_state.dart';

class LoginCubit extends Cubit<LoginState> {
  final LoginUseCase _loginUseCase;

  LoginCubit(this._loginUseCase):super(LoginState.initial());
  
  Future<void> attemptLogin(String email, String password) async {
    if (email.isEmpty || password.isEmpty) {
      emit(state.copyWith(error: "Not all inputs filled"));
      return;
    }
    emit(state.copyWith(loading: true, error: null));
    try {
      final user = await _loginUseCase.execute(email, password);
      if (user != null) {
        emit(state.copyWith(loading: false, success: true, user: user));
      } else {
        emit(state.copyWith(loading: false, error: "Invalid credentials"));
      }
    } catch (e) {
      emit(state.copyWith(loading: false, error: e.toString()));
    }
  }
}
